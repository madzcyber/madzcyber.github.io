# Changelog

## v2.4b18.6
- Added BD-App AutoKill and Disc AutoEject
- Added Plugins Downloader (Thanks to [ctn](https://github.com/ctn123))
- Added AIO fix plugin support (Thanks to [jocover](https://github.com/jocover))
- Updated GoldHEN top supporters page (Thanks to all)

## v2.4b18.5
- Added support for 7.0x, 7.5x, 8.0x, 8.5x, 9.0x, 9.5x, 11.0x, 11.5x
- Added Game Stats support
- Added Date/Time auto update
- Improved BinLoader server (ELF support)

## v2.4b18.4
- Added support for 12.00 and 12.02

## v2.4b18.3
- Added Auto-Apply Cheats on game start
- Added support for 9.03
- Improved Klog server

## v2.4b18.2
- Added PPPoE Patch to avoid multiple exploitations
- Package Scanning Improvements:
  Added support for excluding folders during package scanning. Folders starting with a dot (e.g., ".test") and those containing a ".ignore" file will be automatically skipped.

## v2.4b18
- Added Cheat Downloader
- Added support for 10.50, 10.70 and 10.71
- Improved rest mode support
- Fixed network servers configuration save
- Moved Klog server to userland (better network disconnection supports)

## v2.4b17.3
- Added support for 9.60
- Improved BinLoader server (more payloads supported)
- Improved Klog server (network disconnection supported)
- Changed network servers configuration to declarative

## v2.4b17.2
- Added support for 10.00 / 10.01

## v2.4b17
- Added support for kernel loaders
- Added support for 11.00
- Added syscall 11

## v2.4b16.2
- Improved SysInfo stats
- Fixed IP Address setting

## v2.4b16
- Fixed IP Address overlay position bug 

## v2.4b15
- Improved plugin loader (Thanks to [illusion0001](https://github.com/illusion0001))
- Improved FTP (Thanks to [hippie68](https://github.com/hippie68))
- Added game patch plugin (Thanks to [illusion0001](https://github.com/illusion0001))
- Added game overlay SysInfo (Thanks to [OSM](https://github.com/OSM-Made))
- Added GoldHEN top supporters page in about section (Thanks to all) 

## v2.4b14
- Improved plugin loader (Thanks to [illusion0001](https://github.com/illusion0001))
- Improved FTP (Thanks to [hippie68](https://github.com/hippie68))
- Improved MC4 support (Thanks to [ctn](https://github.com/ctn123))
- Added cheat description support (Thanks to [ctn](https://github.com/ctn123))
- Added background package installation support
- Added package info on package installation support
- Fixed Orbis Toolbox support 

## v2.4b13
- Improved xml/shn parser
- Skipped /disc and $RECYCLE.BIN in pkg subdirectories search

## v2.4b12
- Fixed USB Subdirectories path

## v2.4b11
- Fixed "Search Subdirectories" feature
- Improved "Package Source" feature

## v2.4b10
- Improved FTP self decryption
- Fixed cheat navigation after rest mode
- Added "Search Subdirectories" and "Show Package Path" features in Debug Settings

## v2.4b5
- Added FTP Server v2.1 (Thanks to [hippie68](https://github.com/hippie68))
- Added multi-cheats support
- Added multi-firmware support [5.05 / 6.72 / 9.00]
- Added package installer source settings

## v2.3
- Added [Plugins](https://github.com/GoldHEN/GoldHEN_Plugins_Repository) support
- Added FPS counter
- Added TitleId label feature
- Added MC4 cheat format support
- Added Scanlines overlay
- Added internal pkg installation support (/data/pkg) (Thanks to [OSM](https://github.com/OSM-Made)) 

## v2.2.4
- Fixed KLog tty redirect

## v2.2.3
- Added debug settings
- Added cheat settings
- Added KLog settings
- Added GoldHEN shortcut
- Added PS2 cheat support
- Added Southbridge info
- Improved app version detection
- Refactored GoldHEN menu

## v2.2.2
- Added cheat absolute offset support
- Fixed close option bug
- Fixed Orbis Toolbox support bug

## v2.2.1
- Improved Cheat Menu stability

## v2.2
- Added Cheat Menu initial version
- Added tty redirect to klog

## v2.1.2
- Fixed config parser

## v2.1.1
- Fixed multiple injections

## v2.1
- Added config file (/data/GoldHEN/config.ini)
- Added Klog server on 3232 port
- Improved rest mode support

## v2.0b2
- Improved BinLoader server (still beta version)

## v2.0b
- Added BinLoader server (beta version)
- Added UI menu
- Improved stability and FTP server
- Fixed trophy timestamps

## v1.1
- Improved stability and FTP server

## v1.0
- Public release

# Known issue

## v2.4b17
- klog server: After the pppwn, the klog server is not reachable immediately. A rest mode resume is needed to make it work.
