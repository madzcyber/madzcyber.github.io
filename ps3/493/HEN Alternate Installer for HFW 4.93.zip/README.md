# alternate
PS3HEN Alternate Installer

Created by lmn7, DeViL303, & xps3riments

Additional firmware support by PS3Xploit & Coro

This version is for HFW 4.93 only!

Online installer for OFW 4.80+
https://ps3addict.github.io/alternate